import os
assets_root=os.path.dirname(__file__)