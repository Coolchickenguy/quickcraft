#!/bin/sh
cd assets
./installer.sh