Get-ChildItem "./" -Recurse | Unblock-File
cd assets
./installer.ps1