#!/bin/sh
cd assets
./start.sh